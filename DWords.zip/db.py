import sqlite3
import os
from contextlib import contextmanager
from migrate import SQL_DICT
from version import VERSION_LIST
import global_var as g_var
import utils

# 已禁止并发执行SQL：_in_cursor
class DBHelper:
    def __init__(self,connect_str:str):
        self._conn=None
        self._last_error=''
        self._in_cursor=False
        self._connect_str=connect_str
        self.open()
    
    def get_last_error(self):
        return self._last_error

    def _check_in_cursor(self,is_throw_err:bool):
        if not self._in_cursor:return True
        self._last_error="游标未释放，不能查询"
        if is_throw_err:
            raise self._last_error
        else:
            return False
    # 查询1条数据
    def getOne(self,sql,params=(),is_throw_err:bool=False,is_rs_to_dict:bool=True):
        if not self._check_in_cursor(is_throw_err):return None
        cur=None
        rs=None
        self._last_error=''
        try:
            cur=self._conn.execute(sql,params)
            rs=cur.fetchone()
            if is_rs_to_dict and rs and len(rs)>0:
                rs={cur.description[i][0]:rs[i] for i in range(len(rs))}
        except Exception as ex:
            self._last_error=str(ex)
            if is_throw_err:
                raise self._last_error
            else:
                return None
        finally:
            if not cur:cur.close()
            self._conn.rollback()
        return rs

    # 查询多条数据
    def getAll(self,sql,params=(),is_throw_err:bool=False,is_rs_to_dict:bool=True):
        if not self._check_in_cursor(is_throw_err):return None
        cur=None
        rs=None
        self._last_error=''
        try:
            cur=self._conn.execute(sql,params)
            rs=cur.fetchall()
            if is_rs_to_dict and rs and len(rs)>0:
                irange=range(len(rs[0]))
                rs=[{cur.description[i][0]:r[i] for i in irange} for r in rs]
        except Exception as ex:
            self._last_error=str(ex)
            if is_throw_err:
                raise self._last_error
            else:
                return None
        finally:
            if not cur:cur.close()
            self._conn.rollback()
        return rs

    def open(self):
        self.close()
        self._conn=sqlite3.connect(self._connect_str)
        # 设置查询结果集是字典列表
        # self._conn.row_factory=sqlite3.Row
        self._in_cursor=False

    # 关闭数据库连接
    def close(self):
        if not self._conn:return
        self._conn.close()
        self._conn=None
        self._in_cursor=False

    # 通过游标执行SQL,自动关闭游标
    @contextmanager
    def cursor(self):
        assert not self._in_cursor,"不能获取游标"
        try:
            self._in_cursor=True
            cur=self._conn.cursor()
            yield cur
        except:
            self._conn.rollback()
            raise
        else:
            self._conn.commit()
        finally:
            if cur:cur.close()
            self._in_cursor=False

def get_user_db_file()->str:
    # 用户目录
    if os.name=='nt':
        data_dir=os.path.join(os.environ['USERPROFILE'],'DWords')
    else:
        data_dir=os.path.join(os.environ['HOME'],'DWords')
    if not os.path.isdir(data_dir):os.makedirs(data_dir)
    return os.path.join(data_dir,'user.db')

def get_dict_db_file()->str:
    db_file=utils.get_setting('dictionary')
    if not db_file or not os.path.isfile(db_file):
        db_file=utils.real_path('data/dict.db')
    return db_file

# 获取用户单词本数据库
def get_user_db()->DBHelper:
    db=DBHelper(get_user_db_file())
    return db

# 获取字典数据库
def get_dict_db()->DBHelper:
    db=DBHelper(get_dict_db_file())
    return db

# 初始化用户单词本数据库
def initial_db()->tuple:
    user_db=g_var.user_db()
    if not user_db:
        user_db=get_user_db()
        g_var.setValue('user_db',user_db)
    if not user_db:raise '没有连接user.db数据库'
    if len(VERSION_LIST)<1:raise '没有设置版本列表'
    ver=VERSION_LIST[-1]
    fg=False
    rs=user_db.getOne("select count(*) as cnt from sqlite_master where type='table' and name='sys'")
    if rs and rs['cnt']>0:
        rs=user_db.getOne("select value from sys where id='version'")
        if not rs or ver!=rs['value']:fg=True
    else:
        fg=True
    if not fg:
        dict_db=g_var.dict_db()
        if not dict_db:
            dict_db=get_dict_db()
            g_var.setValue('dict_db',dict_db)
        return user_db,dict_db
    if ver not in SQL_DICT:raise f'没有找到初始化脚本：{ver}'
    user_db.close()
    rs=get_user_db_file()
    if os.path.isfile(rs):os.remove(rs)
    user_db.open()
    with user_db.cursor() as cur:
        cur.executescript(SQL_DICT[ver])
        cur.execute("update sys set value=? where id='version'",(ver,))
    dict_db=g_var.dict_db()
    if not dict_db:
        dict_db=get_dict_db()
        g_var.setValue('dict_db',dict_db)
    return user_db,dict_db
