from PyQt5.QtWidgets import QLabel,QWidget,QVBoxLayout,QHBoxLayout,QRadioButton,QPushButton,QDesktopWidget
from PyQt5.QtGui import QIcon,QFont,QMouseEvent
from PyQt5.QtCore import QTimer,QEvent,pyqtSignal,QRect,Qt
import global_var as g_var
import utils
import copy

class WordLabel(QLabel):
    onMouseEnter=pyqtSignal()
    onMouseLeave=pyqtSignal()
    onMouseDown=pyqtSignal(QMouseEvent)
    onMouseMove=pyqtSignal(QMouseEvent)
    onMouseUp=pyqtSignal(QMouseEvent)

    def __init__(self,*argv,**kw):
        super().__init__(*argv,**kw)
        # 注册监听当前控件事件
        self.installEventFilter(self)

    def enterEvent(self,e):
        self.onMouseEnter.emit()
    
    def leaveEvent(self,e):
        self.onMouseLeave.emit()
    
    def mousePressEvent(self,e):
        self.onMouseDown.emit(e)
    
    def mouseMoveEvent(self,e):
        self.onMouseMove.emit(e)

    def mouseReleaseEvent(self,e):
        self.onMouseUp.emit(e)

# 弹幕控件
class Danmaku(QWidget):
    onModified=pyqtSignal(str)
    onClosing=pyqtSignal(str)
 
    def __init__(self,**kw):
        super().__init__()
        self._data=copy.deepcopy(kw)
        self._stop_move=False
        self._show_detail=False
        # 弹幕是否显示详细信息:默认不显示详细信息
        if 'show_paraphrase' not in self._data or not self._data['show_paraphrase']:self._data['show_paraphrase']=utils.get_setting('danmaku_default_show_paraphrase')
        # 弹幕的背景色:默认白色
        if 'color' not in self._data or not self._data['color']:self._data['color']=utils.get_setting('danmaku_default_color')
        if 'cleared' not in self._data:self._data['cleared']=False
        # 初始化弹幕界面，并立刻显示
        self.initUI()
        # 
        self.initPosition(self._data['y'])

    def initPosition(self,y):
        # 定时器：弹幕移动
        self._timer=QTimer(self)
        self._timer.setTimerType(Qt.PreciseTimer)
        self._timer.timeout.connect(self.timer_event)
        # 设置弹幕可移动多少次
        speed=utils.get_setting("danmaku_speed")
        delta=1
        while round(delta/speed)<17:delta+=1
        self._timer.start(round(delta/speed))
        self._delta=delta
        # 弹幕初始时显示在显示器最右边
        w=QDesktopWidget().availableGeometry().width()
        self.move(w,y)

    def timer_event(self):
        if self._stop_move:return
        x=self.x()-self._delta
        self.move(x,self.y())
        # 当弹幕不在显示区域时，self.close()关闭当前窗口，并立刻销毁
        if x<-self.width():
            self._timer.stop()
            self.onClosing.emit(self._data['word'])
            self.close()

    def initUI(self):
        self.setWindowFlags(self.windowFlags()|Qt.WindowStaysOnTopHint|Qt.FramelessWindowHint|Qt.ToolTip|Qt.X11BypassWindowManagerHint)
        # 启用当前窗口透明效果
        self.setAttribute(Qt.WA_TranslucentBackground,True)
        # 设置WA_DeleteOnClose标志，在关闭窗口(self.close())时，立刻销毁其相关资源
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setWindowOpacity(utils.get_setting('danmaku_transparency'))
        self._lbl_word=WordLabel(self._data['word'])
        self._lbl_word.onMouseEnter.connect(self.mouse_enter_event)
        self._lbl_word.onMouseLeave.connect(self.mouse_level_event)
        self._lbl_word.onMouseDown.connect(self.mouse_down_event)
        self._lbl_word.onMouseMove.connect(self.mouse_move_event)
        self._lbl_word.onMouseUp.connect(self.mouse_up_event)
        self._lbl_word.setFont(QFont('Consolas',18))
        self.set_lbl_word_Qss()
        # 垂直布局
        body=QVBoxLayout()
        self.setLayout(body)
        # 第1行：水平布局
        head=QHBoxLayout()
        head.addWidget(self._lbl_word)
        head.addStretch(1)# 全部填充
        body.addLayout(head)
        # 第2行：显示单词详细信息
        self._continenter=QWidget(self)
        self._continenter.setObjectName('continenter') # 设置控件名字
        self._continenter.setStyleSheet("#continenter{background-color:white;padding:5;border-radius:6px;}") # 通过控件名字设置控件样式
        self._continenter.hide()
        body.addStretch(1) # 设置
        body.addWidget(self._continenter)
        #    详细使用垂直布局
        detail=QVBoxLayout()
        self._continenter.setLayout(detail)
        # <1>.音标
        self.lbl_phonetic=QLabel(self._data['phonetic'])
        self.lbl_phonetic.setObjectName('phonetic')
        self.lbl_phonetic.setFont(QFont('Consolas',13))
        self.lbl_phonetic.setStyleSheet("#phonetic{color:black;text-decoration:underline;}")
        self.lbl_phonetic.setWordWrap(True)
        self.lbl_phonetic.setMaximumWidth(300)
        # 为该控件监听
        self.lbl_phonetic.installEventFilter(self)
        detail.addWidget(self.lbl_phonetic)
        # <2>.翻译
        lbl_paraphrase=QLabel(self._data['paraphrase'])
        lbl_paraphrase.setFont(QFont('Consolas',15))
        lbl_paraphrase.setStyleSheet("QLabel{color:black;}")
        lbl_paraphrase.setWordWrap(True)
        lbl_paraphrase.setMaximumWidth(300)
        detail.addWidget(lbl_paraphrase)
        # <3>.水平布局，单选按钮:选择颜色
        rbtns=QHBoxLayout()
        for name,(color,_) in utils.COLORS.items():
            rbtn=QRadioButton(None)
            rbtn.setChecked(name==self.color)
            rbtn.color=name
            rbtn.setStyleSheet(f"""
            QRadioButton::indicator {{ width:13px; height:13px; background-color:rgb({color}); border: 2px solid rgb({color}); }}
            QRadioButton::indicator:checked {{ border: 2px solid black; }}
            """)
            rbtn.toggled.connect(self.rbtn_color_click)
            rbtns.addWidget(rbtn)
        detail.addLayout(rbtns)
        # <4>.水平布局，button按钮：清除、隐藏
        btns=QHBoxLayout()
        self.btn_clear=QPushButton("重记" if self.cleared else "记住")
        self.btn_clear.setStyleSheet("QPushButton{color:black;}")
        self.btn_clear.clicked.connect(self.btn_clear_click)
        btns.addWidget(self.btn_clear)
        self.btn_paraphrase=QPushButton("隐藏" if self.show_paraphrase else "显示")
        self.btn_paraphrase.setStyleSheet("QPushButton{color:black;}")
        self.btn_paraphrase.clicked.connect(self.btn_paraphrase_click)
        btns.addWidget(self.btn_paraphrase)
        detail.addLayout(btns)
        self._continenter.hide()
        self.show()
    
    def eventFilter(self,source,event) -> bool:
        if(event.type()==QEvent.MouseButtonPress and source is self.lbl_phonetic):
            word=self._data['word']
            rt,msg=g_var.play_audio(word)
        return super().eventFilter(source,event)

    def btn_paraphrase_click(self):
        self.show_paraphrase=not self.show_paraphrase
        self.btn_paraphrase.setText("隐藏" if self.show_paraphrase else "显示")

    def btn_clear_click(self):
        self.cleared=not self.cleared
        self.btn_clear.setText("重记" if self.cleared else "记住")

    def rbtn_color_click(self,e):
        if e:
            sender=self.sender()
            self.color=sender.color
            self.set_lbl_word_Qss()
        
    def set_lbl_word_Qss(self):
        if not self.color:return
        bg_color,font_color=utils.COLORS[self.color]
        self._lbl_word.setStyleSheet(f"QLabel{{background-color:rgb({bg_color});color:rgb({font_color});padding:5;border-radius:6px}}")
    
    @property
    def color(self):
        return self._data['color']

    @color.setter
    def color(self,value):
        self._data['color']=value
        self.onModified.emit('color')
    
    @property
    def cleared(self):
        return self._data['cleared']

    @cleared.setter
    def cleared(self,value):
        self._data['cleared']=value
        self.onModified.emit('cleared')

    @property
    def show_paraphrase(self):
        return self._data['show_paraphrase']

    @show_paraphrase.setter
    def show_paraphrase(self,value):
        self._data['show_paraphrase']=value
        self.onModified.emit('show_paraphrase')

    def mouse_up_event(self,e):
        if e.button()!=Qt.LeftButton:return
        if (e.globalPos()-self._press_start).manhattanLength()<10:
            self._show_detail=not self._show_detail
            if self._show_detail:
                self._stop_move=True
                self._continenter.show()
            else:
                self._stop_move=False
                self._continenter.hide()
                self.adjustSize()
            
    def mouse_move_event(self,e):
        if e.buttons() & Qt.LeftButton:
            self.move(e.globalPos()-self._press_point)
            e.accept()
        
    def mouse_down_event(self,e):
        if e.button()==Qt.LeftButton:
            self._press_point=e.globalPos()-self.pos()
            self._press_start=e.globalPos()
            e.accept()
        
    def mouse_level_event(self):
        # 当鼠标移出，弹幕没有显示详细信息时，设置窗口透明
        if not self._show_detail:
            self.setWindowOpacity(utils.get_setting('danmaku_transparency'))

    def mouse_enter_event(self):
        # 鼠标移入时，设置窗口不透明
        self.setWindowOpacity(1)