from datetime import datetime
import global_var as g_var
import os

def real_path(s_path:str):
    return os.path.join(os.path.dirname(__file__),s_path)

DEFAULT_SETTING = {
    "dictionary": real_path('data/dict.db'),

    "danmaku_speed": 1 / 10,
    "danmaku_frequency": 6000,
    "danmaku_default_show_paraphrase": False,
    "danmaku_default_color": "white",
    "danmaku_transparency": 0.5,
}

COLORS = {
    'red': ("231,76,60", "255,255,255"),
    'yellow': ("241,196,15", "255,255,255"),
    'orange': ("243,156,18", "255,255,255"),
    'cyan': ("26,188,156", "255,255,255"),
    'green': ("46,204,113", "255,255,255"),
    'blue': ("52,152,219", "255,255,255"),
    'purple': ("155,89,182", "255,255,255"),
    'dark': ("52,73,94", "255,255,255"),
    'white': ("236,240,241", "0,0,0"),
}

VALUE_RANGE = {
    "danmaku_speed": (1 / 18, 1 / 5),
    "danmaku_frequency": (3000, 20000),
    "danmaku_transparency": (0.3, 1.0),
}

def now_str(fmt:str='%Y-%m-%d %H:%M:%S'):
    return datetime.now().strftime(fmt)

def now()->datetime:
    return datetime.now()

def get_setting(key:str):
    user_db=g_var.user_db()
    rs=user_db.getOne('select value from setting where key = ?',(key,))
    if not rs:
        return DEFAULT_SETTING[key] if key in DEFAULT_SETTING else None
    else:
        return eval(rs['value'])

def set_setting(key:str,value):
    user_db=g_var.user_db()
    # repr函数将对象转换为字符串
    value_str=repr(value)
    with user_db.cursor() as cur:
        cur.execute('replace into seting(key,value) values(?,?)',(key,value_str))

def rnd_one_word(*not_in_words)->dict:
    user_db=g_var.user_db()
    ilen=len(not_in_words)
    if ilen>0:
        p=",".join('?'*ilen)
        return user_db.getOne(f"select word,phonetic,replace(paraphrase,'<br>','\r') as paraphrase,show_paraphrase,color from words where cleared=0 and word not in ({p}) order by random() limit 1",not_in_words)
    else:
        return user_db.getOne("select word,phonetic,replace(paraphrase,'<br>','\r') as paraphrase,show_paraphrase,color from words where cleared=0 order by random() limit 1")

def query_word(word:str)->dict:
    db=g_var.dict_db()
    rs=db.getOne("select word,phonetic,replace(paraphrase_zh,'<br>','\r') as paraphrase from dict_en where word = ?",(word,))
    return rs

def query_user_word(word:str)->dict:
    db=g_var.user_db()
    rs=db.getOne("select word,phonetic,replace(paraphrase,'<br>','\r') as paraphrase,show_paraphrase,color from words where word = ?",(word,))
    return rs

def update_word(word,**kw):
    user_db=g_var.user_db()
    if 'modify_time' not in kw:kw['modify_time']=now()
    with user_db.cursor() as c:
        c.execute("update words set "+','.join([f"`{r}`=?" for r in kw])+" where word=?",[kw[r] for r in kw]+[word])

def add_words(words)->bool:
    _type=type(words)
    if _type==dict:
        words=[words] if len(words)>0 else []
    elif _type==list:
        words=[r for r in words if type(r)==dict and len(r)>0]
    else:
        return False
    if len(words)<1:return False
    user_db=g_var.user_db()
    try:
        with user_db.cursor() as cur:
            for r in words:
                cur.execute('select count(*) as cnt from words where word=?',(r['word'],))
                rs=cur.fetchone()
                if not rs and rs['cnt']>0:
                    if 'time' in r: del r['time']
                    if 'modify_time' not in r:r['modify_time']=now()
                    cur.execute(f"update words set {','.join([k+'=?' for k in r if k!='word'])} where word=?",[r[k] for k in r if k!='word']+[r['word']])
                else:
                    if 'time' not in r:r['time']=now()
                    if 'modify_time' not in r:r['modify_time']=now()
                cur.execute(f"insert into words({','.join([k for k in r])}) values({','.join('?'*len(r))})",[r[k] for k in r])
        return True
    except:
        return False

def del_words(words)->bool:
    _type=type(words)
    if _type==str:
        words=(words.strip()) if words.strip() else ()
    elif _type==list:
        words=(r.strip() for r in words if type(r)==str and len(r.strip())>0)
    else:
        return False
    if len(words)<1:return
    user_db=g_var.user_db()
    with user_db.cursor() as cur:
        cur.execute(f"delete from words where word in ({','.join('?'*len(words))})",words)
    return True

def progress2value(key, progress):
    MIN, MAX = VALUE_RANGE[key]
    return MIN + (MAX - MIN) * (progress / 99)

def value2progress(key, value):
    MIN, MAX = VALUE_RANGE[key]
    return int((value - MIN) / (MAX - MIN) * 99)