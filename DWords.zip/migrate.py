SQL_DICT={}

SQL_DICT['0.0.1']="""
create table words (
    word varchar(128) primary key,
    phonetic varchar(128),
    paraphrase text not null default '',
    show_paraphrase bool,
    color varchar(32),
    cleared bool not null default 0,
    time datetime not null,
    modify_time datetime not null
);

create table setting (
    key varchar(128) primary key,
    value text not null default 'None'
);

create table sys(
    id varchar(128),
    value text not null default '',
    primary key(id)
);
insert into sys(id,value) values('version','-1');
"""