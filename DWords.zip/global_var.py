import os
import utils
from db import DBHelper
from PyQt5.QtMultimedia import QMediaPlayer,QMediaContent
from PyQt5.QtCore import QUrl

def init():
    global _g_dict,_g_player
    _g_dict={}
    _g_player=QMediaPlayer(None)

def setValue(key,value):
    _g_dict[key]=value

def getValue(key,defValue=None):
    if key in _g_dict:
        return _g_dict[key]
    else:
        return defValue

def remove(key):
    if key in _g_dict:
        del _g_dict[key]
        return True
    else:
        return False

def user_db()->DBHelper:
    return _g_dict['user_db'] if 'user_db' in _g_dict else None

def dict_db()->DBHelper:
    return _g_dict['dict_db'] if 'dict_db' in _g_dict else None

def play_audio(word:str,volume:int=80)->tuple:
    file=utils.real_path(f'audio/{word[0:1]}/{word}.mp3')
    if not os.path.isfile(file):
        return False,f'not found file {os.path.abspath(file)}'
    try:
        _g_player.stop()
        media_content=QMediaContent(QUrl.fromLocalFile(file))
        _g_player.setMedia(media_content)
        _g_player.setVolume(volume) # 80%的音量
        _g_player.play()
        return True,os.path.abspath(file)
    except Exception as ex:
        return False,str(ex)