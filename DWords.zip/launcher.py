from PyQt5.QtWidgets import QDesktopWidget,QMessageBox
from PyQt5.QtCore import QTimer,QObject,pyqtSignal
import random
from danmaku import Danmaku
import global_var as g_var
import utils

class Launcher(QObject):
    onChangeWordCleared=pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self._is_run=False
        self._danmakus={} # 当前弹幕列表
        self._burst_words=set()
        # 定时器：创建弹幕窗口
        self._timer=QTimer(self)
        self._timer.timeout.connect(self.new_danmaku)
        # 默认间隔6秒显示1个弹幕
        self._timer.start(utils.get_setting('danmaku_frequency'))
        # 立刻显示一个弹幕
        self.new_danmaku()

    def clear(self):
        for danmaku in self._danmakus.values():
            danmaku.destroyed.disconnect()
            danmaku.close()
    
    # 将未记住的单词加入弹幕单词列表：self._burst_words
    def burst(self):
        if self._burst_words:return
        curr_words=list(self._danmakus.keys())
        words=g_var.user_db().getAll(f"select word from words where cleared=0 and word not in ({','.join('?'*len(curr_words))})",curr_words,is_rs_to_dict=False)
        self._burst_words=set([r[0] for r in words])
        if not self._burst_words:return
        self._timer.setInterval(1500)

    # 间隔n秒显示1个弹幕
    def new_danmaku(self):
        if self._is_run:return
        self._is_run=True
        try:
            if self._burst_words:
                word=random.choice(list(self._burst_words))
                rs=utils.query_user_word(word)
                self._burst_words.remove(word)
            else:
                rs=utils.rnd_one_word(*self._danmakus.keys())
                if not rs:return
                word=rs['word']
                self._timer.setInterval(utils.get_setting('danmaku_frequency'))
            # 在桌面垂直方向生成1个随机y坐标
            h=QDesktopWidget().availableGeometry().height()
            rs['y']=random.randrange(0,int(h/2))
            # 实例化1个弹幕窗口
            danmaku=Danmaku(**rs)
            # 在关闭弹幕窗口之前，移除弹幕窗口对象
            danmaku.onClosing.connect(self.on_danma_close)
            danmaku.onModified.connect(self.modifyWord)
            self._danmakus[word]=danmaku
        except Exception as ex:
            QMessageBox.critical(None,'Launcher',str(ex))
        finally:
            self._is_run=False

    def on_danma_close(self,word):
        if word in self._danmakus:
            del self._danmakus[word]

    def modifyWord(self,attr_name):
        danmaku=self.sender()
        utils.update_word(danmaku._data['word'],**{attr_name:danmaku._data[attr_name]})
        if attr_name=='cleared':
            self.onChangeWordCleared.emit(danmaku._data['word'])

