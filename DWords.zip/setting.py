from PyQt5.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,QPushButton,QTabWidget,QWidget,QLabel,QLineEdit,QGroupBox,QSlider
from PyQt5.QtGui import QIcon,QFont
from PyQt5.QtCore import Qt
import utils
from version import VERSION

class Setting(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.initUI()
        self.show()

    def initUI(self):
        self.setWindowTitle("设置")
        self.setWindowIcon(QIcon(utils.real_path("img/logo.svg")))
        self.setMinimumWidth(330)
        # 设置窗口关闭时释放资源
        self.setAttribute(Qt.WA_DeleteOnClose)
        # 垂直布局
        layout=QVBoxLayout()
        self.setLayout(layout)
        # 第1行：tab
        tab_setting=QTabWidget()
        layout.addWidget(tab_setting)
        # 
        self._tpage_common=self.tpage_common()
        self._tpage_danmaku=QWidget()
        self._tpage_about=QWidget()
        tab_setting.addTab(self._tpage_common,"通用")
        tab_setting.addTab(self._tpage_danmaku,"弹幕")
        tab_setting.addTab(self._tpage_about,"关于")

    def tpage_common(self)->QWidget:
        # 垂直布局
        layout=QVBoxLayout()
        tpage=QWidget()
        tpage.setLayout(layout)
        # 第1行：水平布局
        self.txt_dict=QLineEdit()
        self.txt_dict.setText(utils.get_setting('dictionary'))
        self.btn_dict=QPushButton('选择')
        layout1=QHBoxLayout()
        layout1.addWidget(QLabel('字典：'))
        layout1.addWidget(self.txt_dict)
        layout1.addWidget(self.btn_dict)
        layout.addLayout(layout1)
        # 第2行：弹幕设置
        grp=QGroupBox()
        grp.setTitle('弹幕：')
        layout.addWidget(grp)
        
        layout_danmu=QVBoxLayout()
        grp.setLayout(layout_danmu)
        speed=utils.get_setting("danmaku_speed")
        lbl_speed=QLabel("速度：%.2f"%(speed*100))
        layout_danmu.addWidget(lbl_speed)

        self.slider=QSlider(Qt.Horizontal)
        self.slider.setValue(utils.get_setting('danmaku_frequency'))
        
        self.lbl_color=QLabel()
        layout_danmu.addRow(QLabel('速度：'),self.txt_dict)
        layout_danmu.addRow(QLabel('频率：'),self.slider)
        layout_danmu.addRow(QLabel('显示：'),self.txt_dict)
        layout_danmu.addRow(QLabel('颜色：'),self.lbl_color)
        layout_danmu.addRow(QLabel('透明：'),self.txt_dict)
        return tpage

# DEFAULT_SETTING = {
#     "dictionary": real_path('data/dict.db'),

#     "danmaku_speed": 1 / 10,
#     "danmaku_frequency": 6000,
#     "danmaku_default_show_paraphrase": False,
#     "danmaku_default_color": "white",
#     "danmaku_transparency": 0.5,
# }