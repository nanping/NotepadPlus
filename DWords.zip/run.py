import sys
from app import App

def run_app():
    app=App(sys.argv)
    sys.exit(app.exec_())

if __name__=='__main__':
    run_app()
