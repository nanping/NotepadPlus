from PyQt5.QtWidgets import QApplication,QSystemTrayIcon,QMessageBox,QMenu
from PyQt5.QtGui import QFont,QIcon
from utils import real_path
import db
import global_var as g_var
from main import MainWin
from launcher import Launcher
from setting import Setting

class App(QApplication):
    def __init__(self, argv):
        super().__init__(argv)
        self.initial_data()
    
    def initial_data(self):
        g_var.init()
        self._user_db,self._dict_db=db.initial_db()
        self._mainwin=MainWin()
        self._mainwin.onClickBurst.connect(self.burst_click)
        self._mainwin.onClickSetting.connect(self.setting_click)
        # 弹幕管理：每n秒显示1个弹幕
        self._launcher=Launcher()
        # 在变更单词状态时：刷新主窗口grid内容
        self._launcher.onChangeWordCleared.connect(self._mainwin.fill_tree_words)
        self._setting=None
        # 设置关闭窗口，不退出应用程序
        self.setQuitOnLastWindowClosed(False)
        self.setTrayIcon()
    
    # 设置托盘
    def setTrayIcon(self):
        tray_icon=QSystemTrayIcon(QIcon(real_path('img/logo.svg')),self)
        menu=QMenu()
        menu.addAction('弹幕').triggered.connect(self.burst_click)
        menu.addAction('设置').triggered.connect(self.setting_click)
        menu.addAction('退出').triggered.connect(self.close)
        tray_icon.setContextMenu(menu)
        tray_icon.activated.connect(self.trayIcon_click)
        tray_icon.setToolTip('单词本')
        tray_icon.show()

    def trayIcon_click(self,e):
        if e==QSystemTrayIcon.Trigger:
            pass
    
    def close(self):
        self._launcher.clear()
        self._user_db.close()
        self._dict_db.close()
        self.quit()
    
    def setting_click(self):
        if self._setting:
            self._setting.showNormal()
            self._setting.activateWindow()
        else:
            self._setting=Setting(self._mainwin)
            self._setting.destroyed.connect(self.on_setting_close)

    def burst_click(self):
        self._launcher.burst()

    def on_setting_close(self):
        self._setting=None
