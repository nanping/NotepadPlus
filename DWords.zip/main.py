from PyQt5.QtWidgets import (QMessageBox,QWidget,QTextEdit,QVBoxLayout,QFormLayout,QHBoxLayout,QLabel,QTabWidget,
QTreeWidget,QTreeWidgetItem,QPushButton,QMenu,QRadioButton,QLineEdit,QStatusBar)
from PyQt5.QtGui import QIcon,QFont,QPixmap,QBrush,QColor
from PyQt5.QtCore import pyqtSignal,Qt,QEvent
import utils
import global_var as g_var

class MainWin(QWidget):
    onClickBurst=pyqtSignal()
    onClickSetting=pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self._is_hide_paraphrase=False
        self._order_type='Time'
        self.init_ui()
        self.show()

    def init_ui(self):
        self.setWindowTitle('DWords')
        self.setWindowIcon(QIcon(utils.real_path('img/logo.svg')))
        self.setMinimumWidth(400)
        # 窗口使用垂直布局
        layout=QVBoxLayout()
        self.setLayout(layout)
        # 第1行使用水平布局：图标、标题
        layout1=QHBoxLayout()
        icon=QLabel()
        icon.setPixmap(QPixmap(utils.real_path('img/logo.svg')).scaled(50,50,transformMode=Qt.SmoothTransformation))
        title=QLabel('DWords')
        title.setFont(QFont('Consolas',18))
        title.font().setStyleStrategy(QFont.PreferAntialias)
        layout1.addWidget(icon)
        layout1.addWidget(title)
        layout1.addStretch(1)
        layout.addLayout(layout1)
        layout.addSpacing(0)
        layout.setContentsMargins(8,8,8,1)

        # 第2行使用tab控件
        tab=QTabWidget()
        tab.setMinimumHeight(300)
        def create_page():
            tree=QTreeWidget()
            tree.setContextMenuPolicy(Qt.CustomContextMenu)
            tree.customContextMenuRequested.connect(self.tree_contextMenu) # 右键菜单
            tree.itemDoubleClicked.connect(self.tree_item_double_click) # 朗读单词
            tree.setColumnCount(3)
            tree.setHeaderLabels(['单词','读音','翻译'])
            return tree
        self._cur_words=create_page()
        self._cleared_words=create_page()
        self._all_words=create_page()
        self.fill_tree_words()
        tab.addTab(self._cur_words,'未记住')
        tab.addTab(self._cleared_words,'已记住')
        tab.addTab(self._all_words,'所有单词')
        layout.addWidget(tab)

        # 第3行使用水平布局：加号(展开)、排序
        layout2=QHBoxLayout()
        btn_add=QPushButton('+')
        btn_add.setFixedWidth(22)
        btn_add.setToolTip('点击：展开面板，输入新单词！')
        btn_add.clicked.connect(self.click_add)
        rbtn_by_time=QRadioButton('时间')
        rbtn_by_time.setChecked(True)
        rbtn_by_time.toggled.connect(self.rbtn_click)
        rbtn_by_word=QRadioButton('A-Z')
        rbtn_by_word.toggled.connect(self.rbtn_click)
        layout2.addWidget(btn_add)
        layout2.addStretch(1)
        layout2.addWidget(QLabel('排序：'))
        layout2.addWidget(rbtn_by_time)
        layout2.addWidget(rbtn_by_word)
        layout.addLayout(layout2)

        # 第4行水平布局：Burst、Setting
        layout3=QHBoxLayout()
        btn_burst=QPushButton('弹幕')
        btn_burst.clicked.connect(self.btn_burst_click) # 转发单击事件
        btn_setting=QPushButton('设置')
        btn_setting.clicked.connect(self.btn_setting_click) # 转发单击事件
        layout3.addStretch(1)
        layout3.addWidget(btn_burst)
        layout3.addWidget(btn_setting)
        layout.addLayout(layout3)

        # 第5行显示编辑器
        self._editor=self.setEditor()
        layout.addWidget(self._editor)

        # 第6行显示状态栏
        self._statusbar=QStatusBar()
        self._statusbar.setSizeGripEnabled(False)
        layout.addWidget(self._statusbar)
        self._statusbar.showMessage('状态')

    def click_add(self):
        btn=self.sender()
        if btn.text()=='+':
            btn.setText('-')
            btn.setToolTip('点击：折叠面板！')
            self.showEditor()
        else:
            btn.setText('+')
            btn.setToolTip('点击：展开面板，输入新单词！')
            self._editor.hide()

    def showEditor(self,info:dict=None):
        self._editor.show()
        if info:
            self._txt_word.setText(info['word'])
            self._txt_phonetic.setText(info['phonetic'])
            self._txt_paraphrase.setText(info['paraphrase'])
            self._txt_phonetic.setFocus()

    def tree_item_double_click(self,item,col):
        self.play_audio(item.text(0))
            
    def play_audio(self,word:str):
        rt,msg=g_var.play_audio(word)
        if rt:
            self._statusbar.showMessage(f'play : {msg}')
        else:
            self._statusbar.showMessage(f'error : {msg}')

        # 朗读单词
    def eventFilter(self,source,event):
        if(event.type()==QEvent.KeyPress and source is self._txt_word):
            self.word_keyPress_event(source,event.key(),event.text())
        return super().eventFilter(source,event)

    def setEditor(self):
        editor=QWidget(self)
        editor.hide()
        layout=QVBoxLayout()
        editor.setLayout(layout)
        # 1.输入框布局
        layout1=QFormLayout()
        self._txt_word=QLineEdit('')
        self._txt_word.placeholderText='按回车键：翻译'
        # 对_txt_word启用键盘输入监听
        self._txt_word.installEventFilter(self)
        self._txt_phonetic=QLineEdit('')
        self._txt_paraphrase=QTextEdit('')
        self._txt_paraphrase.setMinimumHeight(50)
        layout1.addRow(QLabel('单词'),self._txt_word)
        layout1.addRow(QLabel('音标'),self._txt_phonetic)
        layout1.addRow(QLabel('翻译'),self._txt_paraphrase)
        layout.addLayout(layout1)
        # 2.水平布局：按钮
        layout2=QHBoxLayout()
        btn_commit=QPushButton('提交')
        btn_commit.clicked.connect(self.btn_commit_click)
        btn_close=QPushButton('关闭')
        btn_close.clicked.connect(self.hide_editor)
        layout2.addStretch(1) # 设置使得按钮靠右
        layout2.addWidget(btn_commit)
        layout2.addWidget(btn_close)
        layout.addLayout(layout2)
        return editor

    def btn_commit_click(self):
        word=self._txt_word.text().strip()
        if len(word)<1:
            QMessageBox.warning(None,'警告','请输入单词！')
            self._txt_word.setFocus()
            return
        paraphrase=self._txt_paraphrase.toPlainText().strip()
        if len(paraphrase)<1:
            QMessageBox.warning(None,'警告','请输入翻译！')
            self._txt_paraphrase.setFocus()
            return
        info={'word':word,'phonetic':self._txt_phonetic.text().strip(),'paraphrase':paraphrase}
        if not utils.add_words(info):return
        self.fill_tree_words()
        self.clear_editor()
        self._txt_word.setFocus()

    def hide_editor(self):
        self._editor.hide()
        self.clear_editor()

    def clear_editor(self):
        self._txt_word.clear()
        self._txt_phonetic.clear()
        self._txt_paraphrase.clear()

    def btn_burst_click(self):
        self.onClickBurst.emit()

    def btn_setting_click(self):
        self.onClickSetting.emit()

    def tree_contextMenu(self,pos):
        obj=self.sender()
        item=obj.itemAt(pos)
        if not item:return
        menu=QMenu()
        menu._data_=item._data_
        menu.addAction('编辑').triggered.connect(self.menu_click)
        menu.addAction('重记' if item._data_['cleared'] else '记住').triggered.connect(self.menu_click)
        menu.addAction('删除').triggered.connect(self.menu_click)
        menu.exec(obj.mapToGlobal(pos))

    def menu_click(self):
        action=self.sender()
        act=action.text()
        info=action.parent()._data_
        is_refresh=False
        if act=='编辑':
            self.showEditor(info)
        elif act=='记住':
            utils.add_words({'word':info['word'],'cleared':True})
            is_refresh=True
        elif act=='重记':
            utils.add_words({'word':info['word'],'cleared':False})
            is_refresh=True
        elif act=='删除':
            if QMessageBox.question(self,'询问',f'确认删除单词 [{info["word"]}] ？')==QMessageBox.Yes:
                if utils.del_words(info['word']):is_refresh=True
        if is_refresh:self.fill_tree_words(info['word'])

    def word_keyPress_event(self,txtbox,key,text):
        if key!=Qt.Key_Return:return
        word=txtbox.text().strip()
        if len(word)<1:return
        info=utils.query_word(word)
        if not info:return
        self._txt_phonetic.setText(info['phonetic'])
        self._txt_paraphrase.setText(info['paraphrase'])
        self._txt_phonetic.setFocus()

    def rbtn_click(self,e):
        if e:
            rbtn=self.sender()
            self._order_type=rbtn.text()
            self.fill_tree_words()
        
    def fill_tree_words(self):
        def create_item(rs:dict)->QTreeWidgetItem:
            item=QTreeWidgetItem()
            item.setText(0,rs['word'])
            item.setText(1,rs['phonetic'])
            item.setText(2,rs['paraphrase'])
            item._data_=rs
            if rs['cleared']:
                item.setForeground(0,QBrush(QColor(0x27ae60)))
                item.setForeground(1,QBrush(QColor(0x27ae60)))
                item.setForeground(2,QBrush(QColor(0x27ae60)))
            return item
        if self._order_type=='A-Z':
            order_by='order by word'
        else:
            order_by='order by time desc,word'
        user_db=g_var.user_db()
        self._cur_words.clear()
        for rs in user_db.getAll(f"select * from words where cleared=0 {order_by}"):
            self._cur_words.addTopLevelItem(create_item(rs))

        self._cleared_words.clear()
        for rs in user_db.getAll(f"select * from words where cleared=1 {order_by}"):
            self._cleared_words.addTopLevelItem(create_item(rs))

        self._all_words.clear()
        for rs in user_db.getAll(f"select * from words  {order_by}"):
            self._all_words.addTopLevelItem(create_item(rs))
        