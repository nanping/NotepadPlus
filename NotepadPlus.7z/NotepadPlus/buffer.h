﻿#ifndef BUFFER_H
#define BUFFER_H

#include <stdio.h>
#include <Qsci/qsciscintilla.h>


typedef void* Document;

enum class EolType: std::uint8_t
{
    windows,
    macos,
    unix,

    // special values
    unknown, // can not be the first value for legacy code
    osdefault = windows,
};

enum LangType {L_TEXT, L_PHP , L_C, L_CPP, L_CS, L_OBJC, L_JAVA, L_RC,\
               L_HTML, L_XML, L_MAKEFILE, L_PASCAL, L_BATCH, L_INI, L_ASCII, L_USER,\
               L_ASP, L_SQL, L_VB, L_JS, L_CSS, L_PERL, L_PYTHON, L_LUA, \
               L_TEX, L_FORTRAN, L_BASH, L_FLASH, L_NSIS, L_TCL, L_LISP, L_SCHEME,\
               L_ASM, L_DIFF, L_PROPS, L_PS, L_RUBY, L_SMALLTALK, L_VHDL, L_KIX, L_AU3,\
               L_CAML, L_ADA, L_VERILOG, L_MATLAB, L_HASKELL, L_INNO, L_SEARCHRESULT,\
               L_CMAKE, L_YAML, L_COBOL, L_GUI4CLI, L_D, L_POWERSHELL, L_R, L_JSP,\
               L_COFFEESCRIPT, L_JSON, L_JAVASCRIPT, L_FORTRAN_77, L_BAANC, L_SREC,\
               L_IHEX, L_TEHEX, L_SWIFT,\
               L_ASN1, L_AVS, L_BLITZBASIC, L_PUREBASIC, L_FREEBASIC, \
               L_CSOUND, L_ERLANG, L_ESCRIPT, L_FORTH, L_LATEX, \
               L_MMIXAL, L_NIMROD, L_NNCRONTAB, L_OSCRIPT, L_REBOL, \
               L_REGISTRY, L_RUST, L_SPICE, L_TXT2TAGS, L_VISUALPROLOG,\
               // Don't use L_JS, use L_JAVASCRIPT instead
               // The end of enumated language type, so it should be always at the end
               L_EXTERNAL};

struct LanguageName {
    const char * lexerName;
    const char * shortName;
    const char * longName;
    LangType LangID;
    int lexerID;
};

enum UniMode {uni8Bit=0, uniUTF8=1, uni16BE=2, uni16LE=3, uniCookie=4, uni7Bit=5, uni16BE_NoBOM=6, uni16LE_NoBOM=7, uniEnd};

enum DocFileStatus
{
    DOC_REGULAR    = 0x01, // should not be combined with anything
    DOC_UNNAMED    = 0x02, // not saved (new ##)
    DOC_DELETED    = 0x04, // doesn't exist in environment anymore, but not DOC_UNNAMED
    DOC_MODIFIED   = 0x08, // File in environment has changed
    DOC_NEEDRELOAD = 0x10  // File is modified & needed to be reload (by log monitoring)
};

struct Position
{
    int _firstVisibleLine = 0;
    int _startPos = 0;
    int _endPos = 0;
    int _xOffset = 0;
    int _selMode = 0;
    int _scrollWidth = 1;
};

class Buffer
{
    friend class FileManager;
public:
    //保存文档位置，以便下次显示时恢复
    Position pos;
    static LanguageName langNames[L_EXTERNAL+1];
private:
    QString fileName="";
    Document doc=nullptr;
    DocFileStatus currentStatus=DOC_UNNAMED;
};

//C++11关键字final表示禁止该类继承
class FileManager final
{
public:
    //探查文件编码
    bool detectEncoding=true;
    void init(QsciScintilla *_pEdit);
    //检查语言类别
    static LangType detectLanguageFromTextBegining(const unsigned char *data,const size_t dataLen);
    //检查是否包含BOM
    static UniMode determineEncoding(const unsigned char *buf, size_t bufLen);
    Buffer *loadFile(const QString &fileName,Document doc=nullptr,int encoding=-1);
private:
    struct FileFormat {
        LangType language=LangType::L_TEXT;
        std::string encoding="";
        EolType eolFormat=EolType::unknown;
    };
    int uSaveNewFileCount=0;
    QVector<Buffer*> _buffers;
    QsciScintilla *pEdit=nullptr;
    Document _scratchDocDefault=nullptr;
    Buffer *newEmptyDocument();
    bool loadFileData(Document doc, const QString &filename, FileFormat& fileFormat);
};



#endif // BUFFER_H
