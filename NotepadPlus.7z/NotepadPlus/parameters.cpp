﻿#include "parameters.h"
#include "tools.h"

Parameters *Parameters::pInstance=new Parameters();

Parameters::Parameters()
{

}

Parameters::~Parameters()
{
    if(pLanObj)
    {
        delete pLanObj;
        pLanObj=nullptr;
    }
    if(pCfObj)
    {
        delete pCfObj;
        pCfObj=nullptr;
    }
}

void Parameters::init()
{
    pLanObj=Languages::getInstancePtr();
    pLanObj->init();
    pCfObj=new ConfigFile();
    if(pCfObj->loadXml())
    {
        lanType=getValue(eGUIConfigs,"GUIConfig[@name='language']","中文简体");
    }
}

void Parameters::changeLanguage(const QString &_lanType)
{
    if(_lanType.isEmpty())
    {
        if(lanType.isEmpty()) return;
        if(!pLanObj->load(lanType)) return;
    }
    else{
        if(!pLanObj->load(_lanType)) return;
        lanType=_lanType;
    }
    //菜单加载完毕后，通知UI更新，以实现类之间解耦
    emit ParameterValueChanged(MSG_LANGUAGE_CHANGE);
}

const QString &Parameters::getLanType()
{
    return lanType;
}

bool Parameters::getHistoryMenus(QVector<QString> &files)
{
    if(!pCfObj->isOpen()) return false;
    QString v=pCfObj->getAttribute(createParameterStr(eHistory),"nbMaxFile","");
    int maxFiles;
    if(v.isEmpty())
    {
        maxFiles=10;
    }else{
        bool ok;
        maxFiles=v.toInt(&ok);
        if(!ok || maxFiles<1) {
            maxFiles=10;
        }else{
            if(maxFiles>30) maxFiles=10;
        }
    }
    if(!pCfObj->getNodesSameAttr(createParameterStr(eHistory,"File"),"filename",files)) return false;
    while(files.count()>maxFiles)
    {
        files.removeAt(maxFiles);
    }
    return files.count()>0;
}

ConfigFile *Parameters::getConfig()
{
    return pCfObj;
}

Parameters *Parameters::getInstancePtr()
{
    return pInstance;
}

const QString Parameters::createParameterStr(const ParameterType type,const QString &xpath)
{
    switch(type)
    {
    case ParameterType::eGUIConfigs:
        return xpath.isEmpty() ? "/NotepadPlus/GUIConfigs": QString("/NotepadPlus/GUIConfigs/%1").arg(xpath);
    case ParameterType::eHistory:
        return xpath.isEmpty() ? "/NotepadPlus/History": QString("/NotepadPlus/History/%1").arg(xpath);
    case ParameterType::eFindHistory:
        return xpath.isEmpty() ? "/NotepadPlus/FindHistory": QString("/NotepadPlus/FindHistory/%1").arg(xpath);
    case ParameterType::eProjectPanels:
        return xpath.isEmpty() ? "/NotepadPlus/ProjectPanels": QString("/NotepadPlus/ProjectPanels/%1").arg(xpath);
    }
    return "";
}

bool Parameters::equalAttrValue(const ParameterType type,const QString &xpath,const QString &attrName, const QString &compareValue,const QString &defValue, Qt::CaseSensitivity cs)
{
    return (pCfObj->getAttribute(createParameterStr(type,xpath),attrName,defValue).compare(compareValue,cs)==0);
}

bool Parameters::setAttrValue(const ParameterType type,const QString &xpath, const QString &attrName, const QString &value,const int fireID,const void *data)
{
    auto rt= pCfObj->setAttribute(createParameterStr(type,xpath),attrName,value);
    if(rt && fireID>0)  emit ParameterValueChanged(fireID,data);
    return rt;
}

bool Parameters::setValue(const ParameterType type,const QString &xpath, const QString &value,const int fireID,const void *data)
{
    auto rt= pCfObj->setNodeValue(createParameterStr(type,xpath),value);
    if(rt && fireID>0)  emit ParameterValueChanged(fireID,data);
    return rt;
}

bool Parameters::equalValue(const ParameterType type,const QString &xpath, const QString &compareValue, const QString &defValue, Qt::CaseSensitivity cs)
{
    return (pCfObj->getValue(createParameterStr(type,xpath),defValue).compare(compareValue,cs)==0);
}

const QString Parameters::getValue(const ParameterType type,const QString &xpath,const QString &defValue)
{
    return pCfObj->getValue(createParameterStr(type,xpath),defValue);
}
