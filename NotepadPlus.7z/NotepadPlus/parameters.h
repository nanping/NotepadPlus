﻿#ifndef PARAMETERS_H
#define PARAMETERS_H

#include "languages.h"
#include "configfile.h"

#define MSG_LANGUAGE_CHANGE 1
#define MSG_TOOLBAR_CHANGE 2

//遍历不定参数，不定参数展开 <=9个
//vs中这种方式定义宏过度也不能用
#define  EXTAND_ARGS(args) args //__VA_ARGS__在vs中会被认为是一个实参，所以需要定义该宏过度

#define FOR_EACH_1(what,ParamType, ...) what(ParamType,1)
#define FOR_EACH_2(what,ParamType, ...) what(ParamType,2), EXTAND_ARGS(FOR_EACH_1(what, __VA_ARGS__))
#define FOR_EACH_3(what,ParamType, ...) what(ParamType,3), EXTAND_ARGS(FOR_EACH_2(what, __VA_ARGS__))
#define FOR_EACH_4(what,ParamType, ...) what(ParamType,4), EXTAND_ARGS(FOR_EACH_3(what, __VA_ARGS__))
#define FOR_EACH_5(what,ParamType, ...) what(ParamType,5), EXTAND_ARGS(FOR_EACH_4(what, __VA_ARGS__))
#define FOR_EACH_6(what,ParamType, ...) what(ParamType,6), EXTAND_ARGS(FOR_EACH_5(what, __VA_ARGS__))
#define FOR_EACH_7(what,ParamType, ...) what(ParamType,7), EXTAND_ARGS(FOR_EACH_6(what, __VA_ARGS__))
#define FOR_EACH_8(what,ParamType, ...) what(ParamType,8), EXTAND_ARGS(FOR_EACH_7(what, __VA_ARGS__))
#define FOR_EACH_9(what,ParamType, ...) what(ParamType,9), EXTAND_ARGS(FOR_EACH_8(what, __VA_ARGS__))


#define CONCATENATE(arg1, arg2)  arg1##arg2

//Parameters Table
#define PARAM_TABLE(ParamType,N) ParamType param##N
#define PARAM_TABLE_FOR_EACH_(N,...) EXTAND_ARGS(CONCATENATE(FOR_EACH_, N)(PARAM_TABLE,__VA_ARGS__))

// Parameters Name
#define PARAM_NAME(ParamType,N) param##N
#define PARAM_NAME_FOR_EACH_(N,...) EXTAND_ARGS(CONCATENATE(FOR_EACH_, N)(PARAM_NAME,__VA_ARGS__))


// 计算 __VA_ARGS__ 参数个数,最大支持64个参数 //vs中无参数时会返回1
#define FL_ARG_COUNT(...) EXTAND_ARGS(FL_INTERNAL_ARG_COUNT_PRIVATE(0, __VA_ARGS__,\
    64, 63, 62, 61, 60, \
    59, 58, 57, 56, 55, 54, 53, 52, 51, 50, \
    49, 48, 47, 46, 45, 44, 43, 42, 41, 40, \
    39, 38, 37, 36, 35, 34, 33, 32, 31, 30, \
    29, 28, 27, 26, 25, 24, 23, 22, 21, 20, \
    19, 18, 17, 16, 15, 14, 13, 12, 11, 10, \
    9,  8,  7,  6,  5,  4,  3,  2,  1,  0))
#define FL_INTERNAL_ARG_COUNT_PRIVATE(\
    _0,  _1,  _2,  _3,  _4,  _5,  _6,  _7,  _8,  _9, \
    _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, \
    _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, \
    _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, \
    _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, \
    _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, \
    _60, _61, _62, _63, _64, N, ...) N




#define EXTEND_1(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,1)
#define EXTEND_2(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,2), EXTAND_ARGS(EXTEND_1(what, __VA_ARGS__))
#define EXTEND_3(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,3), EXTAND_ARGS(EXTEND_2(what, __VA_ARGS__))
#define EXTEND_4(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,4), EXTAND_ARGS(EXTEND_3(what, __VA_ARGS__))
#define EXTEND_5(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,5), EXTAND_ARGS(EXTEND_4(what, __VA_ARGS__))
#define EXTEND_6(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,6), EXTAND_ARGS(EXTEND_5(what, __VA_ARGS__))
#define EXTEND_7(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,7), EXTAND_ARGS(EXTEND_6(what, __VA_ARGS__))
#define EXTEND_8(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,8), EXTAND_ARGS(EXTEND_7(what, __VA_ARGS__))
#define EXTEND_9(what,type,tagName,idName,idValue,propertyName, ...) what(type,tagName,idName,idValue,propertyName,9), EXTAND_ARGS(EXTEND_8(what, __VA_ARGS__))

#define ATTRIBUTE_FOR_EACH_(what,type,tagName,idName,idValue,propertyName,N,...) EXTAND_ARGS(CONCATENATE(FOR_EACH_, N)(CREATE_ATTRIBUTE,__VA_ARGS__))


#define CREATE_GET_ATTRIBUTE(type,tagName,idName,idValue,propertyName) QString get##idValue##_##propertyName(const QString &defValue=""){ \
    return pCfObj->getAttribute(createParameterStr((type),QString("%1[@%2='%3']").arg(#tagName).arg(#idName).arg(#idValue)),#propertyName,defValue);\
}

#define CREATE_SET_ATTRIBUTE(type,tagName,idName,idValue,propertyName) bool set##idValue##_##propertyName(const QString &value){ \
    return pCfObj->setAttribute(createParameterStr((type),QString("%1[@%2='%3']").arg(#tagName).arg(#idName).arg(#idValue)),#propertyName,value);\
}

#define CREATE_GET_VALUE(type,tagName,idName,idValue) QString get##idValue##Value(const QString &defValue=""){ \
    return pCfObj->getValue(createParameterStr((type),QString("%1[@%2='%3']").arg(#tagName).arg(#idName).arg(#idValue)),defValue);\
}

#define CREATE_SET_VALUE(type,tagName,idName,idValue) bool set##idValue##Value(const QString &value){ \
    return pCfObj->setNodeValue(createParameterStr((type),QString("%1[@%2='%3']").arg(#tagName).arg(#idName).arg(#idValue)),value);\
}

#define CREATE_ATTRIBUTE(type,tagName,idName,idValue,propertyName) \
    CREATE_GET_ATTRIBUTE(type,tagName,idName,idValue,propertyName) \
    CREATE_SET_ATTRIBUTE(type,tagName,idName,idValue,propertyName)

#define CREATE_VALUE(type,tagName,idName,idValue) \
    CREATE_GET_VALUE(type,tagName,idName,idValue) \
    CREATE_SET_VALUE(type,tagName,idName,idValue)

#define CREATE_PROPERTIES (type,tagName,idName,idValue,...) \
    CREATE_VALUE(type,tagName,idName,idValue) \


//#define  DeclarationAndDifinitionInterface(funcName,...) \
//    int funcName(PARAM_TABLE_FOR_EACH_(EXTAND_ARGS(FL_ARG_COUNT(__VA_ARGS__)),__VA_ARGS__))      \
//    {                                                  \
//        return 1;                  \
//    }

//#define  createGetProperty(tagName,...) \
//    bool is##tagName(PARAM_TABLE_FOR_EACH_(EXTAND_ARGS(FL_ARG_COUNT(__VA_ARGS__)),__VA_ARGS__))      \
//    {                                                  \
//        return true;                  \
//    }\
//    \
//    void set##tagName(PARAM_TABLE_FOR_EACH_(EXTAND_ARGS(FL_ARG_COUNT(__VA_ARGS__)),__VA_ARGS__))\
//    {\
//        \
//    }

enum ParameterType
{
    eFindHistory,
    eHistory,
    eGUIConfigs,
    eProjectPanels
};
//当类中有虚函数(纯虚函数)时，就必须定义析构函数，否则会报警告 'xxx' has virtual functions but non-virtual destructor
class Parameters final:public QObject
{
    //使用信号、槽，类必须继承QObject，并且必须在此使用宏Q_OBJECCT
    Q_OBJECT
private:
    Languages *pLanObj=nullptr;
    ConfigFile *pCfObj=nullptr;
    QString lanType="";
    static Parameters *pInstance;

    Parameters();
    ~Parameters();//在此定义析构函数，去除编译警告
public:
    void init();
    void changeLanguage(const QString &_lanType="");
    const QString &getLanType();
    bool getHistoryMenus(QVector<QString> &files);
    ConfigFile *getConfig();
    static Parameters *getInstancePtr();
    static const QString createParameterStr(const ParameterType type,const QString &xpath="");
    bool equalAttrValue(const ParameterType type,const QString &xpath,const QString &attrName,const QString &compareValue,const QString &defValue="",Qt::CaseSensitivity cs=Qt::CaseInsensitive);
    bool setAttrValue(const ParameterType type,const QString &xpath,const QString &attrName,const QString &value,const int fireID=-1,const void *data=nullptr);
    bool setValue(const ParameterType type,const QString &xpath,const QString &value,const int fireID=-1,const void *data=nullptr);
    bool equalValue(const ParameterType type,const QString &xpath,const QString &compareValue,const QString &defValue="",Qt::CaseSensitivity cs=Qt::CaseInsensitive);
    const QString getValue(const ParameterType type,const QString &xpath,const QString &defValue="");
    //使用宏自动构建方法代码
    CREATE_ATTRIBUTE(ParameterType::eGUIConfigs,GUIConfig,name,ToolBar,visible)
    CREATE_ATTRIBUTE(ParameterType::eGUIConfigs,GUIConfig,name,TabBar,dragAndDrop)

    CREATE_VALUE(ParameterType::eGUIConfigs,GUIConfig,name,ToolBar)
    CREATE_VALUE(ParameterType::eGUIConfigs,GUIConfig,name,TabBar)

signals:
    //参数改变通知
    void  ParameterValueChanged(const int msg,const void *data=nullptr);
};

#endif // PARAMETERS_H
